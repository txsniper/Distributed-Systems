package mapreduce

import (
	//"fmt"
	"os"
	"encoding/json"
	"io"
	//"log"
    "bufio"
)

// doReduce does the job of a reduce worker: it reads the intermediate
// key/value pairs (produced by the map phase) for this task, sorts the
// intermediate key/value pairs by key, calls the user-defined reduce function
// (reduceF) for each key, and writes the output to disk.
func doReduce(
	jobName string, // the name of the whole MapReduce job
	reduceTaskNumber int, // which reduce task this is
	nMap int, // the number of map tasks that were run ("M" in the paper)
	reduceF func(key string, values []string) string,
) {
	// TODO:
	// You will need to write this function.
	// You can find the intermediate file for this reduce task from map task number
	// m using reduceName(jobName, m, reduceTaskNumber).
	// Remember that you've encoded the values in the intermediate files, so you
	// will need to decode them. If you chose to use JSON, you can read out
	// multiple decoded values by creating a decoder, and then repeatedly calling
	// .Decode() on it until Decode() returns an error.
	//
	// You should write the reduced output in as JSON encoded KeyValue
	// objects to a file named mergeName(jobName, reduceTaskNumber). We require
	// you to use JSON here because that is what the merger than combines the
	// output from all the reduce tasks expects. There is nothing "special" about
	// JSON -- it is just the marshalling format we chose to use. It will look
	// something like this:
	//
	// enc := json.NewEncoder(mergeFile)
	// for key in ... {
	// 	enc.Encode(KeyValue{key, reduceF(...)})
	// }
	// file.Close()

	// 你需要完成这个函数。你可与获取到来自map任务生产的中间数据，通过reduceName获取到文件名。
	//  记住你应该编码了值到中间文件,所以你需要解码它们。如果你选择了使用JSON,你通过创建decoder读取到多个
	// 解码之后的值，直接调用Decode直到返回错误。
	//
	// 你应该将reduce输出以JSON编码的方式保存到文件，文件名通过mergeName获取。我们建议你在这里使用JSON,

	// key是中间文件里面键值，value是字符串,这个map用于存储相同键值元素的合并

	// Reduce的过程如下：
	//  S1: 获取到Map产生的文件并打开(reduceName获取文件名)
	// 　S2：获取中间文件的数据(对多个map产生的文件更加值合并)
	// 　S3：打开文件（mergeName获取文件名），将用于存储Reduce任务的结果
	// 　S4：合并结果之后(S2)，进行reduceF操作, work count的操作将结果累加，也就是word出现在这个文件中出现的次数
    input_data := make(map[string][]string)
    for i:= 0; i < nMap; i++ {
        file_name := reduceName(jobName, i, reduceTaskNumber)
        _, err := os.Stat(file_name)
        if err == nil {
            f, err := os.Open(file_name)
            if err != nil {
                panic(err)
            }
            defer f.Close()

            rd := bufio.NewReader(f)
            for {
                line_bytes, err := rd.ReadBytes('\n')
                if err != nil || io.EOF == err {
                    break
                }
                line := string(line_bytes)
                line_len := len(line)
                line = line[:line_len - 1]
                key, value_arr := decode(line)
                /*
                if _, ok := input_data[key]; ok == false {
                    input_data[key] = make([]string, 5)
                }
                */
                input_data[key] = append(input_data[key], value_arr...)
            }
        }
    }
    merge_name := mergeName(jobName, reduceTaskNumber)
    output_file, err := os.OpenFile(merge_name, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
    defer output_file.Close()
    if err != nil {
        panic(err)
    }
    enc := json.NewEncoder(output_file)
    for key, value_arr := range input_data {
        ret_str := reduceF(key, value_arr)
        enc.Encode(KeyValue{key, ret_str})
    }
}

func decode(line string) (string, []string) {
    var map_out map[string][]string
    err := json.Unmarshal([]byte(line), &map_out)
    if err != nil {
        panic(err)
    }
    var key string
    var value_arr []string
    for key_temp, value_arr_temp := range map_out {
        key = key_temp
        value_arr = value_arr_temp
    }
    return key, value_arr
}
