package mapreduce

import "fmt"

func (mr *Master)schedule_internal(args *DoTaskArgs, worker_name string) (ok bool) {
	ok = call(worker_name, "Worker.DoTask", args, new(struct{}))
	debug("schedule: DoTask Finished\n")
	if ok == false {
		fmt.Printf("call worker DoTask failed")
	}
	return
}
// schedule starts and waits for all tasks in the given phase (Map or Reduce).
func (mr *Master) schedule(phase jobPhase) {
	var ntasks int
	var nios int // number of inputs (for reduce) or outputs (for map)
	debug("schedule: Wait new worker\n")
	worker_name := <-mr.registerChannel
	debug("schedule: Get new worker\n")
	switch phase {
	case mapPhase:
		ntasks = len(mr.files)
		nios = mr.nReduce
		for i:= 0; i < ntasks; i++ {
			args := new(DoTaskArgs)
			args.JobName = mr.jobName
			args.File = mr.files[i]
			args.Phase = phase
			args.TaskNumber = i
			args.NumOtherPhase = nios
			_ = mr.schedule_internal(args, worker_name)
		}
		
	case reducePhase:
		ntasks = mr.nReduce
		nios = len(mr.files)
		for i:= 0; i < ntasks; i++ {
			args := new(DoTaskArgs)
			args.JobName = mr.jobName
			args.File = "empty"
			args.Phase = phase
			args.TaskNumber = i
			args.NumOtherPhase = nios
			_ = mr.schedule_internal(args, worker_name)
		}
	}

	fmt.Printf("Schedule: %v %v tasks (%d I/Os)\n", ntasks, phase, nios)

	// All ntasks tasks have to be scheduled on workers, and only once all of
	// them have been completed successfully should the function return.
	// Remember that workers may fail, and that any given worker may finish
	// multiple tasks.
	//
	// TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO
	//
	 
	fmt.Printf("Schedule: %v phase done\n", phase)
}
